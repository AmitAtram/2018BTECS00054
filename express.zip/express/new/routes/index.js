var express = require('express'); 
var mysql = require('mysql')
var router = express.Router();
const app=express()
const port=3000


/* GET home page. */
router.get('/', function(req, res, next) {
  res.render('index', { title: 'Express' });
});
router.get('/user', function(req, res, next) {
  res.render('index', { title: 'user' });
});
var connection = mysql.createConnection({
  host: 'localhost',
  user: 'root',
  password: '',
  database: 'amit'
})
connection.connect(function(err)
{
  if(err) throw err;
  console.log('Connected');
})

router.post('/submit', function(req,res)
{
  console.log(req.body);



var sql="insert into food values('"+req.body.experience +"','"+ req.body.FullName +"','"+req.body.Email +"',"+req.body.Age +",'"+req.body.Phone +"','"+req.body.Message+"')";
connection.query(sql,function(err){
  if(err) throw err;
  res.render('index',{title:'Data Saved', 
  message: 'Data Saved Successfully.'})
});
  
connection.end();
})
module.exports = router;
